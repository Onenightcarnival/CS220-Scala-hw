import Lists._
class TestSuite extends org.scalatest.FunSuite {
	test("oddNumbers properly defined") { 
		assert( oddNumbers == List(1, 3, 5) ) 
	} 

	test("sumDouble properly defined") {
		assert( sumDouble(1 :: 2 :: 3 :: Nil) == 12)
		assert( sumDouble(1 :: Nil) == 2)
	}

	test("removeZeroes properly defined") {
		assert( removeZeroes(0 :: 0 :: 1 :: 5 :: 0:: Nil) == (1 :: 5 :: Nil))
		assert( removeZeroes(0 :: Nil) == (Nil))
	}

	test("countEvens properly defined") {
		assert( countEvens(1 :: 2 :: 3 :: Nil) == 1)
	}

	test("removeAlternation properly defined") {
		assert( removeAlternation("a" :: "b" :: "c" :: "d" :: Nil) == ("a" :: "c" :: Nil))
	}

	test("isAscending properly defined") {
		assert( isAscending(1 :: 2 :: 3 ::Nil) == true)
	}

	test("addSub properly defined") {
		assert( addSub(1 :: 2 :: 3 :: 4 ::Nil) == -2)
	}

	test("alternate properly defined") {
		assert( alternate((1 :: 3 :: 5 :: 7 :: 9 :: Nil), (2 :: 4 :: 6 :: 8 :: 10 :: Nil)) == (1 :: 2 :: 3 :: 4 :: 5 :: 6 :: 7 :: 8 :: 9 :: 10 :: Nil))
	}

	test("fromTo properly defined") {
		assert( fromTo(1, 5) == (1 :: 2 :: 3 :: 4 :: 5 :: Nil))
	}

	test("insertOrdered properly defined") {
		assert( insertOrdered(4, (1 :: 5 :: 8 :: 9 :: Nil)) == (1 :: 4 :: 5 :: 8 :: 9 :: Nil))
		assert( insertOrdered(4, (4 :: 4 :: Nil)) == (4 :: 4 :: 4 :: Nil))
		assert( insertOrdered(4, (4 :: 5 :: Nil)) == (4 :: 4 :: 5 :: Nil))
		assert( insertOrdered(4, (3 :: 2 :: 5 :: Nil)) == (3 :: 2 :: 4 :: 5 :: Nil))
	}

	test("sort properly defined") {
		assert( sort(4 :: 1 :: 6 :: 3 :: Nil) == (1 :: 3 :: 4 :: 6 :: Nil))
	}
}
